#! /bin/bash
#
# command to compile c++ program with g++ compiler
#--------------------------------------------------------------

g++ -o scheduling Scheduling.cpp Reader.cpp Galaxy.h Galaxy.cpp
