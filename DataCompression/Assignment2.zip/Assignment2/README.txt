README.txt 

Gihwan Kwon (Kris) 1534798 
CSS343 - Data Structures, Algorithms, Discrete Mathematics 2
Assignment 2 - Data compression
-----------------------------------------------------------------

<TEXT URL> 
CommonSense.txt and CommonSense1.txt 
http://www.gutenberg.org/cache/epub/147/pg147.txt

<ORIGINAL TEXT SIZE> 
random.txt: 2.7KiB 
CommonSense.txt: 144.7KiB
CommonSense1.txt: 144.7 KiB

<COMPRESSED TEXT SIZE> 
random.huff: 1.9KiB
CommonSense.huff: 82.4KiB
CommonSense1.huff: 82.4KiB

<SPACE SAVING> 
random: 0.2962
CommonSense: 0.4305
CommonSense1: 0.4305 
