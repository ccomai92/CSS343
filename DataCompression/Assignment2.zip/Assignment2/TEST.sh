#! /bin/bash 
# 
# 
# Checking the difference between original .txt and .puff 

diff random.txt random.puff 
diff CommonSense.txt CommonSense.puff
diff CommonSense1.txt CommonSense1.puff
